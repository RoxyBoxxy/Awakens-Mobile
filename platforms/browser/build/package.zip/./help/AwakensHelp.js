$(document).ready(function(){
	$(".open1").toggle();
	$(".button1").click(function(){
		$(".open1").toggle();
	});
});

$(document).ready(function(){
	$(".open2").toggle();
	$(".button2").click(function(){
		$(".open2").toggle();
	});
});

$(document).ready(function(){
	$(".open3").toggle();
	$(".button3").click(function(){
		$(".open3").toggle();
	});
});

$(document).ready(function(){
	$(".open4").toggle();
	$(".button4").click(function(){
		$(".open4").toggle();
	});
});

$(document).ready(function(){
	$(".open5").toggle();
	$(".button5").click(function(){
		$(".open5").toggle();
	});
});

$(document).ready(function(){
	$(".open6").toggle();
	$(".button6").click(function(){
		$(".open6").toggle();
	});
});

$(document).ready(function(){
	$(".open7").toggle();
	$(".button7").click(function(){
		$(".open7").toggle();
	});
});

$(document).ready(function(){
	$(".open8").toggle();
	$(".button8").click(function(){
		$(".open8").toggle();
	});
});

$(document).ready(function(){
	$(".open9").toggle();
	$(".button9").click(function(){
		$(".open9").toggle();
	});
});

$(document).ready(function(){
	$(".open10").toggle();
	$(".button10").click(function(){
		$(".open10").toggle();
	});
});

$(document).ready(function(){
	$(".open11").toggle();
	$(".button11").click(function(){
		$(".open11").toggle();
	});
});